import os, shutil, math, pickle, time
from PIL import Image, ImageFont, ImageDraw
from datetime import datetime

from helpers import exception_helper, image_helper
from helpers import request_helper
import constants

class ShopModule:
    _SHOP_IMAGE_SIZE = 3000

    _SHOP_MODULE_PATH = os.path.dirname(os.path.abspath(__file__))
    _TEMP_PATH = os.path.join(_SHOP_MODULE_PATH, "temp")
    _RESULT_PATH = os.path.join(_SHOP_MODULE_PATH, "result")
    _LAST_SHOP_UID_PATH = os.path.join(_SHOP_MODULE_PATH, "last_shop_uid.p")

    _API_SHOP_URL = "https://fortniteapi.io/v2/shop"
    _RETURN_COLOR = (247, 223, 61)

    def __init__(self):
        if not os.path.exists(self._RESULT_PATH):
            os.makedirs(self._RESULT_PATH)

    def register(self, schedule):
        schedule.every(1).minutes.do(self.update)
    
    @exception_helper.catch_exceptions()
    def update(self):
        shop_json = request_helper.io_request(self._API_SHOP_URL, {"fields": "id,name,shopHistory,images"})
        shop_date = self._parse_shop_date(shop_json)
        shop_uid = shop_json['lastUpdate']['uid']

        if self._has_new_shop(shop_uid):
            print("New shop detected!")

            self._generate_icons(shop_json, shop_date)
            shop_image = self._merge_shop()
            self._compress_image(shop_image, shop_date)
            
            print("Shop generated successfully!")
            shutil.rmtree(self._TEMP_PATH)

            if constants.TWITTER_ENABLED:
                print("Posting Shop on Twitter.")
                self._post_on_twitter(shop_date)
                print("Shop posted successfully!")
            
            pickle.dump(shop_uid, open(self._LAST_SHOP_UID_PATH, "wb"))
        
    def _parse_shop_date(self, shop_json):
        return shop_json['lastUpdate']['date'][:10]

    def _has_new_shop(self, shop_uid):
        last_shop_uid = (pickle.load(open(self._LAST_SHOP_UID_PATH, "rb")) 
                    if os.path.exists(self._LAST_SHOP_UID_PATH)
                        else None)

        return last_shop_uid != shop_uid

    def _generate_icons(self, shop_json, shop_date):
        sections = {section:i for i, section in enumerate(shop_json["currentRotation"].keys())}
        shop_offers_json = shop_json['shop']

        # Create temp folder
        if os.path.exists(self._TEMP_PATH):
            shutil.rmtree(self._TEMP_PATH)
        os.mkdir(self._TEMP_PATH)

        # Load assets
        rainbow_image = image_helper.from_path(os.path.join(constants.ASSETS_PATH, 'rainbow.png'))
        overlay_image = image_helper.from_path(os.path.join(constants.ASSETS_PATH, 'overlay.png'))
        new_badge = image_helper.from_path(os.path.join(constants.ASSETS_PATH, "new_badge.png"))
        # granted_overlay = image_helper.from_path(os.path.join(constants.ASSETS_PATH, 'granted_overlay.png'), size=100)

        for offer_i, offer_json in enumerate(shop_offers_json):
            item_background_url = offer_json['displayAssets'][0]['background']

            is_bundle = offer_json['mainType'] == "bundle"
            main_id = ("bundle_" if is_bundle else "") + offer_json['mainId']
            offer_price = offer_json['price']['finalPrice']
            offer_section = offer_json['section']['id']

            shop_history = offer_json['granted'][0]['shopHistory']

            last_seen = None
            if shop_history is not None and len(shop_history) >= 2:
                if shop_history[-1] == shop_date:
                    last_seen = shop_history[-2]
                else:
                    last_seen = shop_history[-1]
            
            if last_seen is not None:
                dateloop = datetime.strptime(last_seen, "%Y-%m-%d")
                current = datetime.strptime(shop_date, "%Y-%m-%d")
                seen_diff = current.date() - dateloop.date()
                days_gone = seen_diff.days
            else:
                days_gone = None

            #Save Background
            icon_image = image_helper.from_url(item_background_url)

            '''
            #Granted Items
            granted_json = offer_json["granted"]

            draw_i = 0
            for i in range(3):
                if i >= len(granted_json) - 1:
                    continue

                try:
                    granted_item_json = granted_json[i]

                    if not is_bundle and granted_item_json["id"] == main_id:
                        continue
                    
                    icon_image.paste(granted_overlay, (-20, draw_i * 100 - 20), granted_overlay)

                    granted_item_icon_url = granted_item_json['images']['icon']
                    granted_item_icon = image_helper.from_url(granted_item_icon_url, size=80)
                    icon_image.paste(granted_item_icon, (0, draw_i * 100), granted_item_icon)

                    draw_i += 1
                except Exception as e:
                    print(f"Error while drawing granted item. ({e})")
            '''

            #Overlay
            icon_image.paste(overlay_image, (0, 0), overlay_image)

            if days_gone is None:
                icon_image.paste(rainbow_image, (0, 0), rainbow_image)

            item_name = offer_json['displayName']
            
            #Smaller text to fit image
            font = None
            font_size = 45
            while font is None or font.getlength(item_name) > 450:
                font = ImageFont.truetype(constants.FONT_PATH, font_size)
                font_size -= 2

            draw = ImageDraw.Draw(icon_image)
            draw.text((256, 423), item_name.upper(), font=font, fill='white', anchor='ms') #Writes display name

            info_text = "NOVO COSMÉTICO"
            if days_gone is not None:
                info_text = f'VISTO HÁ: {days_gone} dias atrás'

            font = ImageFont.truetype(constants.FONT_PATH, 33)
            draw = ImageDraw.Draw(icon_image)
            draw.text((256, 463), info_text, font=font, fill=((255, 255, 255) if days_gone is None or days_gone < 100 else self._RETURN_COLOR), anchor='ms') #Writes info text / date last seen

            font = ImageFont.truetype(constants.FONT_PATH, 40)
            draw = ImageDraw.Draw(icon_image)
            draw.text((256, 505), str(offer_price), font=font, fill='white', anchor='ms') #Writes price of offer

            #New badge
            if days_gone is None:
                icon_image.paste(new_badge, (0, 0), new_badge)

            section_number = sections[offer_section] if offer_section in sections else len(sections)

            #Save image
            icon_image.save(os.path.join(self._TEMP_PATH, f'{section_number}_{offer_i}_{main_id}.png'))
            icon_image.close()

        # Free memory
        rainbow_image.close()
        overlay_image.close()
        new_badge.close()
        # granted_overlay.close()

        print(f'Generated {len(shop_offers_json)} items from the {shop_date} item shop.')

    def _merge_shop(self):
        offer_image_paths = []
        for filepath in os.listdir(self._TEMP_PATH):
            offer_image_paths.append(os.path.join(self._TEMP_PATH, filepath))
        offer_count = len(offer_image_paths)
            
        column_count = math.ceil(math.sqrt(offer_count))
        offer_image_size = self._SHOP_IMAGE_SIZE // column_count
        shop_image_size = offer_image_size * column_count

        shop_image = Image.new("RGB", (shop_image_size, shop_image_size))
        shop_background = image_helper.from_path(os.path.join(constants.ASSETS_PATH, "background.png"), size=shop_image_size)
        shop_image.paste(shop_background, (0, 0))
        shop_background.close() # Free memory

        for i, offer_image_path in enumerate(sorted(offer_image_paths)):
            offer_image = image_helper.from_path(offer_image_path, size=offer_image_size)
            shop_image.paste(
                offer_image,
                ((0 + ((i % column_count) * offer_image.width)),
                    (0 + ((i // column_count) * offer_image.height)))
            )
            offer_image.close() # Free memory
        
        #Credits
        try:
            spare_cells = column_count ** 2 - offer_count
            if spare_cells >= 1:
                credits_image = image_helper.from_path(os.path.join(constants.ASSETS_PATH, "ad_kapirosco.png"), size=offer_image_size)
                shop_image.paste(credits_image, (shop_image_size - offer_image_size, shop_image_size - offer_image_size), credits_image)
                credits_image.close() # Free memory
            if spare_cells >= 2:
                credits_image = image_helper.from_path(os.path.join(constants.ASSETS_PATH, "ad_mike.png"), size=offer_image_size)
                shop_image.paste(credits_image, (shop_image_size - offer_image_size * 2, shop_image_size - offer_image_size), credits_image)
                credits_image.close() # Free memory
        except Exception as e:
            if isinstance(e, FileNotFoundError) and "m" in os.path.basename(e.filename):
                pass
            print(f"Error generating credits ({e})")

        return shop_image

    def _compress_image(self, image, shop_date):
        save_path = os.path.join(self._RESULT_PATH, f'shop_{shop_date}.jpg')

        current_size = self._SHOP_IMAGE_SIZE
        size_step = 250
        size_limit = 3000000

        start_time = time.time()
        while os.path.getsize(save_path) > size_limit:
            image = image.resize((current_size, current_size), Image.Resampling.LANCZOS)
            image.save(save_path, optimize=True, quality=85)

            current_size -= size_step

        image.close() # Free memory
        print(f"Compressed image to {os.path.getsize(save_path)} bytes. Took {round(time.time() - start_time, 2)} seconds.")

    def _post_on_twitter(self, shop_date):
        split_date = shop_date.split('-')
        reformatted_date = f'{split_date[2]}/{split_date[1]}/{split_date[0]}'

        media = constants.TWITTER_API.media_upload(os.path.join(self._RESULT_PATH, f'shop_{shop_date}.jpg'))
        constants.TWITTER_API.update_status(
            f'🛍 Loja Fortnite {reformatted_date}!\n\n' +
            f'👾 Use o meu código "KAPIROSCO" ao fazer suas compras na Loja e apoie meu trabalho! #ad\n\n' +
            f'#Fortnite!',
            media_ids=[media.media_id]
        )